﻿using SMS.Entities;
using SMS.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Exceptions;
using System.Text.RegularExpressions;

namespace SMS.BLL
{
    public class StudentBLL
    {
        StudentDAL dal = null;

        public StudentBLL()
        {
            dal = new StudentDAL();
        }
        
        public static bool Validate(Student stud)
        {
            bool validated = true;
            StringBuilder message = new StringBuilder();

            try
            {             
                if (!Regex.IsMatch(stud.StudName, "[A-Z][a-z]+"))
                {
                    message.Append("Student Name should start with capital alphabet and it should have alphabets only\n");
                    validated = false;
                }

                if (stud.DOB > DateTime.Today)
                {
                    message.Append("Date of Birth should be less than or equal to current date\n");
                    validated = false;
                }               
                if (!Regex.IsMatch(stud.MobileNo, "[7-9][0-9]{9}"))
                {
                    message.Append("Mobile No should start with 7 or 8 or 9 and it should have 10 digits\n");
                    validated = false;
                }                

                if (validated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validated;
        }
                
        public List<Student> GetAll()
        {
            List<Student> studs = null;
            try
            {                
                studs = dal.SelectAll();
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
            return studs;
        }

        public int Add(Student stud)
        {
            int no = 0;
            try
            {
                if (Validate(stud))
                    no = dal.Insert(stud);
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }

        public int Edit(Student stud)
        {
            int no = 0;

            try
            {
                if (Validate(stud))
                    no = dal.Update(stud);
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }

        public int Remove(int rollNo)
        {
            int no = 0;
            try
            {
                no = dal.Delete(rollNo);
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }
    }
}
