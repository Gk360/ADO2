﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
    public class Student
    {
        public int RollNo { get; set; }
        public String  StudName { get; set; }
        public String  Gender { get; set; }
        public DateTime DOB { get; set; }
        public double FeePaid{ get; set; }
        public String MobileNo { get; set; }
        public String  Email { get; set; }

    }
}
