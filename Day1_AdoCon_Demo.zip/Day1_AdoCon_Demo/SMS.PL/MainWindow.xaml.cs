﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS.BLL;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBLL bll = null;

        public MainWindow()
        {
            InitializeComponent();
            bll = new StudentBLL();
        }

        public void PopulateUI()
        {
            try
            {
                List<Student> studs = bll.GetAll();
                dgStudents.ItemsSource = studs;
                cmbStudName.ItemsSource = studs;
                cmbStudName.DisplayMemberPath = "StudName";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
            
        }

        public string ValidateUI()
        {
            StringBuilder sb = new StringBuilder();          
                       
            if (cmbStudName.Text.Trim() == string.Empty || cmbStudName.Text.Trim() == null)            
                sb.Append("Student-Name is Mandatory"+Environment.NewLine);
            if (txtFeePaid.Text.Trim() == string.Empty || txtFeePaid.Text.Trim() == null)
                sb.Append("Fees-Paid is Mandatory" + Environment.NewLine);
            if (dpDOB.Text.Trim() == string.Empty || dpDOB.Text.Trim() == null)
                sb.Append("DOB is Mandatory" + Environment.NewLine);
            if (txtMobileNo.Text.Trim() == string.Empty || txtMobileNo.Text.Trim() == null)
                sb.Append("Mobile-No is Mandatory" + Environment.NewLine);
            if (txtEmail.Text.Trim() == string.Empty || txtEmail.Text.Trim() == null)
                sb.Append("Email is Mandatory" + Environment.NewLine);

            return sb.ToString();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {  
            string message = ValidateUI();

            if(message == null)
            {
                Student stud = new Student();
                stud.StudName = cmbStudName.Text;
                stud.DOB = (DateTime)dpDOB.SelectedDate;
                stud.FeePaid = double.Parse(txtFeePaid.Text);
                stud.MobileNo = txtMobileNo.Text;
                stud.Email = txtEmail.Text;

                string g = string.Empty;
                if ((bool)rbMale.IsChecked)
                {
                    g = rbMale.Content.ToString();
                }
                else if ((bool)rbFemale.IsChecked)
                {
                    g = rbFemale.Content.ToString();
                }

                try
                {
                    bll.Add(stud);
                    MessageBox.Show("Inserted!");
                }
                catch (StudentException ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                catch (Exception ex2)
                {
                    MessageBox.Show(ex2.Message);
                }
            }
            else
            {
                MessageBox.Show(message);
            }
           
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Student stud =  (Student) cmbStudName.SelectedItem;
            stud.StudName = cmbStudName.Text;
            stud.DOB = (DateTime)dpDOB.SelectedDate;
            stud.FeePaid = double.Parse(txtFeePaid.Text);
            stud.MobileNo = txtMobileNo.Text;
            stud.Email = txtEmail.Text;

            try
            {
                bll.Edit(stud);
                MessageBox.Show("Updated!");
            }
            catch (StudentException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {           
            try
            {
                Student stud = (Student)cmbStudName.SelectedItem;
                bll.Remove(stud.RollNo);
                MessageBox.Show("Deleted!");
            }
            catch (StudentException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        private void btnSelectAll_Click(object sender, RoutedEventArgs e)
        {
            dgStudents.ItemsSource = bll.GetAll();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }
    }
}
