﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace SMS.DAL
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        //SelectAll
        public List<Student> SelectAll()
        {
            List<Student> studs = new List<Student>();          
            try
            {
                //cmd = new SqlCommand("select * from Student_132419", cn);
                cmd = new SqlCommand("amol.USP_SelectAll_Student", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();               
                while (dr.Read())
                {
                    Student s = new Student();
                    s.RollNo = Convert.ToInt32(dr[0]);
                    s.StudName = dr[1].ToString();
                    s.Gender = dr[2].ToString();
                    s.DOB = Convert.ToDateTime(dr[3]);
                    s.FeePaid = Convert.ToDouble(dr[4]);
                    s.MobileNo = dr[5].ToString();
                    s.Email = dr[6].ToString();
                    studs.Add(s);
                }
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }          
            return studs;
        }

        //Insert
        public int Insert(Student stud)
        {
            int no = 0;
            try
            {
                //cmd = new SqlCommand("insert into Student_132419(StudName,Gender,DOB,FeePaid,MobileNo,Email) values('" + stud.StudName + "', '" + stud.Gender + "', '" + stud.DOB + "', " + stud.FeePaid + ", '" + stud.MobileNo + "', '" + stud.Email + "')", cn);
                cmd = new SqlCommand("amol.USP_Insert_Student", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudName", stud.StudName);
                cmd.Parameters.AddWithValue("@Gender", stud.Gender);
                cmd.Parameters.AddWithValue("@DOB", stud.DOB);
                cmd.Parameters.AddWithValue("@FeePaid", stud.FeePaid);
                cmd.Parameters.AddWithValue("@MobileNo", stud.MobileNo);
                cmd.Parameters.AddWithValue("@Email", stud.Email);
                cn.Open(); 
                no = cmd.ExecuteNonQuery();              
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }

        //Update
        public int Update(Student stud)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("update Student_132419 set StudName = '" 
                    + stud.StudName + "',Gender = '" + stud.Gender + "',DOB='" + stud.DOB + 
                    "',FeePaid=" + stud.FeePaid + ", MobileNo = '" + stud.MobileNo + 
                    "', Email = '" + stud.Email + "' where RollNo = "+stud.RollNo, cn);
                cn.Open();
                no = cmd.ExecuteNonQuery();
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }

        //Delete
        public int Delete(int rollNo)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("delete Student_132419 where RollNo = " + rollNo, cn);
                cn.Open();
                no = cmd.ExecuteNonQuery();
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }


    }
}
